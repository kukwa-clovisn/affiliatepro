<template>
  <div class="routes-container">
    <div class="wrapper">menu routes</div>
  </div>
</template>

<script setup>
</script>

<style lang="scss" scoped>
.routes-container {
  width: 100%;
  height: 100%;
  position: relative;
}
</style>