<template>
  <div class="page-container"></div>
</template>

<style lang="scss" scoped>
.page-container {
  width: 100%;
  height: fit-content;
}
</style>